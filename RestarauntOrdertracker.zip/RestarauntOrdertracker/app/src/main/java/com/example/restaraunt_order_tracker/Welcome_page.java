package com.example.restaraunt_order_tracker;

public class Welcome_page extends MainActivity{
}
